var indexSectionsWithContent =
{
  0: "ceglmsu",
  1: "cl",
  2: "e",
  3: "clm",
  4: "su",
  5: "eglsu",
  6: "l",
  7: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Properties",
  7: "Pages"
};

