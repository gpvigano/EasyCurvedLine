var searchData=
[
  ['gizmocolor',['gizmoColor',['../class_easy_curved_line_1_1_curved_line_point.html#a057b307bfbfc54782384485ccd52eb0c',1,'EasyCurvedLine.CurvedLinePoint.gizmoColor()'],['../class_easy_curved_line_1_1_curved_line_renderer.html#a9f4bc40e40d35c4f294c21ab1305fba3',1,'EasyCurvedLine.CurvedLineRenderer.gizmoColor()']]],
  ['gizmosize',['gizmoSize',['../class_easy_curved_line_1_1_curved_line_point.html#a699febabe5c6bb814cd4bbf224adf864',1,'EasyCurvedLine.CurvedLinePoint.gizmoSize()'],['../class_easy_curved_line_1_1_curved_line_renderer.html#a1ad3aefde93e22f681266bc863caa469',1,'EasyCurvedLine.CurvedLineRenderer.gizmoSize()']]]
];
